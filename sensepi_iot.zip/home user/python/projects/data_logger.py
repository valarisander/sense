#!/usr/bin/python

from sense_hat import SenseHat
import os
import threading
import urllib2
import base64
import requests

sense = SenseHat()

def readSensor():

	global temperature
	global humidity
	global pressure
	global cpu_temp

	cpu_temp = 0
	temperature =0
	humidity = 0
	pressure = 0
	
	temperature = sense.get_temperature()
	humidity = sense.get_humidity()+16.5
	pressure = sense.get_pressure()+20

	if pressure == 20 :
		pressure = sense.get_pressure()+20

	humidity = round(humidity,1)
	pressure = round(pressure,1)
	
def readCPUTemperature():	

	global temperature

	cpu_temp = os.popen("/opt/vc/bin/vcgencmd measure_temp").read()
	cpu_temp = cpu_temp[:-3]
	cpu_temp = cpu_temp[5:]
	
	temperature = sense.get_temperature()

	print(cpu_temp)

	if cpu_temp == "42.9":
		temperature = temperature - 8.2
	elif cpu_temp == "44.0":
		temperature = temperature - 8.5
	elif cpu_temp == "44.5":
		temperature = temperature - 8.7
	elif cpu_temp == "45.1":
		temperature = temperature - 9.0
	elif cpu_temp == "46.7":
		temperature = temperature - 9.1
	elif cpu_temp == "47.2":
		temperature = temperature - 9.2
	elif cpu_temp == "47.8":
		temperature = temperature - 9.3	
	elif cpu_temp == "48.3":
		temperature = temperature - 9.35	
	elif cpu_temp == "48.9":
		temperature = temperature - 9.4
	else:
		temperature = temperature - 9.5
######################
def sendDataToServer():
	global temperature
	global pressure
	global humidity
	threading.Timer(30,sendDataToServer).start()
	print("Sensing...")
	readSensor()
	readCPUTemperature()
	temperature = round(temperature,1)
	print(temperature)
	print(humidity)
	print(pressure)
	temp= "%.1f" %temperature
	hum ="%.1f" %humidity
	press = "%.1f" %pressure
#	urllib2.urlopen("http://neusphere.ddns.net:81/add_data.php?temp="+temp+"&humi="+hum+"&pres="+press).read()
	api_url = ("http://neusphere.ddns.net:81/add_data.php?temp="+temp+"&humi="+hum+"&pres="+press)#.read()
	api_username = "root"
	api_password = "Mithril29"
	class PreemptiveBasicAuthHandler(urllib2.HTTPBasicAuthHandler):
		'''Preemptive basic auth.
    	Instead of waiting for a 403 to then retry with the credentials,
    	send the credentials if the url is handled by the password manager.
    	Note: please use realm=None when calling add_password.'''
		def http_request(self, req):
        		url = req.get_full_url()
        	realm = None
        # this is very similar to the code from retry_http_basic_auth()
        # but returns a request object.
        	user, pw = self.passwd.find_user_password(realm, url)
        	if pw:
        	    raw = "%s:%s" % (user, pw)
        	    auth = 'Basic %s' % base64.b64encode(raw).strip()
        	    req.add_unredirected_header(self.auth_header, auth)
        	return req
    	https_request = http_request
	auth_handler = PreemptiveBasicAuthHandler()
	auth_handler.add_password(
    	realm=None, # default realm.
    	uri=api_url,
    	user=api_username,
    	passwd=api_password)
	opener = urllib2.build_opener(auth_handler)
	urllib2.install_opener(opener)
sendDataToServer()