#!/usr/bin/python

##text_scroll.py example##
from sense_hat import SenseHat

SENSE_ATTEMPT = 3

for count in range(SENSE_ATTEMPT):
    sense = SenseHat()
    sense.set_rotation(90)
    red = (255, 0, 0)
    sense.show_message("One small step for Pi!", text_colour=red)