#!/usr/bin/python

from sense_hat import SenseHat
import time

#data recording for averages
SENSE_ATTEMPT = 3
temp_running_total = 0
humi_running_total = 0
press_running_total = 0

#pixel display configuration
sense = SenseHat()
sense.set_rotation(90)
deco = (155, 000, 155)
teco = (255, 000, 000)
heco = (000, 000, 255)
peco = (000, 255, 000)

#data recording block
for count in range(SENSE_ATTEMPT):
    humi = round(sense.get_humidity(), 2)
    time.sleep(0.5)
    humi_running_total += humi
    print("Humidity: %s %%rH" % humi)
    
    temp = round(sense.get_temperature(), 2)
    time.sleep(0.5)
    temp_running_total += temp
    print("Temperature: %s C" % temp)
   
    press = round(sense.get_pressure(), 2)
    time.sleep(0.5)
    press_running_total += press
    print("Pressure: %s Millibars" % press)

#finding the average reading to self-check for bad reading
#display tempurature averages
ave_temp = temp_running_total/SENSE_ATTEMPT
temp_string = "ave_temp: "+ str(round(ave_temp, 2))
sense.show_message(temp_string, text_colour=teco)

#display humidity averages
ave_humi = humi_running_total/SENSE_ATTEMPT
humi_string = "ave_humi: "+ str(round(ave_humi, 2))
sense.show_message(humi_string, text_colour=heco)

#display pressure averages
ave_press = press_running_total/SENSE_ATTEMPT
press_string = "ave_pres: "+ str(round(ave_press, 2))
sense.show_message(press_string, text_colour=peco)

#display current record completion notice
sense.show_message("COMPLETE", text_colour=deco)